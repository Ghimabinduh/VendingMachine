﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.UI.Xaml;

namespace VendingMachine.ViewModel
{
    public enum Coins
    {
        Nickels = 20,
        Dimes = 10,
        Quarters = 4,
        Pennie
    }
    public enum Products
    {
        cola,
        chips,
        candy
    }
    public class VendingMachineViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private List<string> listofProducts = null;
        public static double Balanceamount = 0;
        public List<string> ListofProducts
        {
            get
            {
                return listofProducts;
            }
            set
            {
                listofProducts = value;
                this.NotifyPropertyChanged("ListofProducts");
            }
        }
        private List<string> listofCoins = null;
        public List<string> ListofCoins
        {
            get
            {
                return listofCoins;
            }
            set
            {
                listofCoins = value;
                this.NotifyPropertyChanged("listofCoins");
            }
        }
        private Visibility processVisibility = Visibility.Collapsed;
        public Visibility ProcessVisibility
        {
            get
            {
                return processVisibility;
            }
            set
            {
                processVisibility = value;
                this.NotifyPropertyChanged("ProcessVisibility");
            }
        }
        private string balanceAmounttext = null;
        public string BalanceAmountxt
        {
            get
            {
                return balanceAmounttext;
            }
            set
            {
                balanceAmounttext = value;
                this.NotifyPropertyChanged("BalanceAmountxt");
            }
        }
        private string confirmationtext = null;
        public string Confirmationtext
        {
            get
            {
                return confirmationtext;
            }
            set
            {
                confirmationtext = value;
                this.NotifyPropertyChanged("Confirmationtext");
            }
        }
        private string selectedCoin = null;
        public string SelectedCoin
        {
            get
            {
                return selectedCoin;
            }
            set
            {
                selectedCoin = value;
                SetProcessVisibility(selectedCoin, Balanceamount, SelectedProduct);
                this.NotifyPropertyChanged("SelectedCoin");
            }
        }
        private string selectedProduct = null;
        public string SelectedProduct
        {
            get
            {
                return selectedProduct;
            }
            set
            {
                selectedProduct = value;
                if (Balanceamount > 0)
                {
                    BalanceAmountxt = "Balance amount " + Balanceamount.ToString();
                }
                SetProcessVisibility(SelectedCoin, Balanceamount, SelectedProduct);
                this.NotifyPropertyChanged("SelectedProduct");
            }
        }
        private void SetProcessVisibility(string coin, double bal, string prodcut)
        {
            if ((!string.IsNullOrEmpty(coin) || bal > 0) && prodcut != null)
                ProcessVisibility = Visibility.Visible;
            else
                ProcessVisibility = Visibility.Collapsed;
        }
        public VendingMachineViewModel()
        {
            ListofProducts = new List<string>();
            listofProducts = Enum.GetNames(typeof(Products)).ToList();
            ListofCoins = new List<string>();
            ListofCoins = Enum.GetNames(typeof(Coins)).ToList();
        }

        public async Task<double> ValidateData(string selectedcoin, double balnceamount, string selectedproduct)
        {
            double amount = 0;
            //  double bal = balnceamount;
            if (selectedproduct != null && (balnceamount > 0 || selectedcoin != null))
            {
                if (selectedcoin == null || selectedcoin != Coins.Pennie.ToString())
                {
                    if (selectedcoin == null && balnceamount > 0)
                        amount = balnceamount;
                    if (selectedcoin == Coins.Dimes.ToString())
                    {
                        amount = Convert.ToDouble((int)Coins.Dimes) + balnceamount;
                    }
                    else if (selectedcoin == Coins.Nickels.ToString())
                    {
                        amount = Convert.ToDouble((int)Coins.Nickels) + balnceamount;
                    }
                    else if (selectedcoin == Coins.Quarters.ToString())
                    {
                        amount = Convert.ToDouble((int)Coins.Quarters) + balnceamount;
                    }
                    if (selectedproduct == Products.candy.ToString())
                    {
                        Balanceamount = amount - 0.65;
                    }
                    else if (selectedproduct == Products.cola.ToString())
                    {

                        Balanceamount = amount - 1;
                    }
                    else if (selectedproduct == Products.chips.ToString())
                    {
                        Balanceamount = amount - 0.50;
                    }
                }
                else
                {
                    MessageDialog messageDialog = new MessageDialog("Please insert valid coin");
                    await messageDialog.ShowAsync();
                }
                BalanceAmountxt = "Balance amount " + balnceamount.ToString();

                if (Balanceamount >= 0)
                {
                    // Thread.Sleep(5000);
                    Confirmationtext = " Here is your Product,Thank You!";
                }
                else
                {

                    Balanceamount = balnceamount;
                    Confirmationtext = "";
                    MessageDialog messageDialog = new MessageDialog("Insufficient balance , please insert a coin");
                    await messageDialog.ShowAsync();
                }
                SelectedCoin = null;
                SelectedProduct = null;
                SetProcessVisibility(SelectedCoin, balnceamount, SelectedProduct);
            }
            return Balanceamount;
        }
        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
